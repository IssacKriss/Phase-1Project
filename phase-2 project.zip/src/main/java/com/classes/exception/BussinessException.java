package com.classes.exception;

public class BussinessException extends Exception{

	public BussinessException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BussinessException(final String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
